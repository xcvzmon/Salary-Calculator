﻿namespace Salary_Calculator
{
    partial class FRMMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LBLEmp = new System.Windows.Forms.Label();
            this.TXTEmp = new System.Windows.Forms.TextBox();
            this.LBLFname = new System.Windows.Forms.Label();
            this.TXTFname = new System.Windows.Forms.TextBox();
            this.LBLMname = new System.Windows.Forms.Label();
            this.TXTMname = new System.Windows.Forms.TextBox();
            this.LBLLname = new System.Windows.Forms.Label();
            this.TXTLname = new System.Windows.Forms.TextBox();
            this.CMBPos = new System.Windows.Forms.ComboBox();
            this.LBLPos = new System.Windows.Forms.Label();
            this.LBLDays = new System.Windows.Forms.Label();
            this.PNLMain = new System.Windows.Forms.Panel();
            this.GRPDeduct = new System.Windows.Forms.GroupBox();
            this.CHKSss = new System.Windows.Forms.CheckBox();
            this.CHKEnsurance = new System.Windows.Forms.CheckBox();
            this.CHKTax = new System.Windows.Forms.CheckBox();
            this.LBLDeduct = new System.Windows.Forms.Label();
            this.TXTDeduct = new System.Windows.Forms.TextBox();
            this.LBLNet = new System.Windows.Forms.Label();
            this.TXTNet = new System.Windows.Forms.TextBox();
            this.BTNAdd = new System.Windows.Forms.Button();
            this.LSTMain = new System.Windows.Forms.ListView();
            this.BTNDel = new System.Windows.Forms.Button();
            this.NUMDays = new System.Windows.Forms.NumericUpDown();
            this.LBLSal = new System.Windows.Forms.Label();
            this.TXTSal = new System.Windows.Forms.TextBox();
            this.CLMEmp = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CLMFull = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CLMPos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CLMSal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CLMDeduct = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CLMNet = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.PNLMain.SuspendLayout();
            this.GRPDeduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUMDays)).BeginInit();
            this.SuspendLayout();
            // 
            // LBLEmp
            // 
            this.LBLEmp.AutoSize = true;
            this.LBLEmp.Location = new System.Drawing.Point(91, 22);
            this.LBLEmp.Name = "LBLEmp";
            this.LBLEmp.Size = new System.Drawing.Size(74, 20);
            this.LBLEmp.TabIndex = 0;
            this.LBLEmp.Text = "Emp. No.";
            // 
            // TXTEmp
            // 
            this.TXTEmp.Location = new System.Drawing.Point(176, 16);
            this.TXTEmp.Name = "TXTEmp";
            this.TXTEmp.Size = new System.Drawing.Size(189, 26);
            this.TXTEmp.TabIndex = 0;
            // 
            // LBLFname
            // 
            this.LBLFname.AutoSize = true;
            this.LBLFname.Location = new System.Drawing.Point(79, 54);
            this.LBLFname.Name = "LBLFname";
            this.LBLFname.Size = new System.Drawing.Size(86, 20);
            this.LBLFname.TabIndex = 0;
            this.LBLFname.Text = "First Name";
            // 
            // TXTFname
            // 
            this.TXTFname.Location = new System.Drawing.Point(176, 48);
            this.TXTFname.Name = "TXTFname";
            this.TXTFname.Size = new System.Drawing.Size(189, 26);
            this.TXTFname.TabIndex = 1;
            // 
            // LBLMname
            // 
            this.LBLMname.AutoSize = true;
            this.LBLMname.Location = new System.Drawing.Point(64, 86);
            this.LBLMname.Name = "LBLMname";
            this.LBLMname.Size = new System.Drawing.Size(101, 20);
            this.LBLMname.TabIndex = 0;
            this.LBLMname.Text = "Middle Name";
            // 
            // TXTMname
            // 
            this.TXTMname.Location = new System.Drawing.Point(176, 80);
            this.TXTMname.Name = "TXTMname";
            this.TXTMname.Size = new System.Drawing.Size(189, 26);
            this.TXTMname.TabIndex = 2;
            // 
            // LBLLname
            // 
            this.LBLLname.AutoSize = true;
            this.LBLLname.Location = new System.Drawing.Point(79, 118);
            this.LBLLname.Name = "LBLLname";
            this.LBLLname.Size = new System.Drawing.Size(86, 20);
            this.LBLLname.TabIndex = 0;
            this.LBLLname.Text = "Last Name";
            // 
            // TXTLname
            // 
            this.TXTLname.Location = new System.Drawing.Point(176, 112);
            this.TXTLname.Name = "TXTLname";
            this.TXTLname.Size = new System.Drawing.Size(189, 26);
            this.TXTLname.TabIndex = 3;
            // 
            // CMBPos
            // 
            this.CMBPos.FormattingEnabled = true;
            this.CMBPos.Items.AddRange(new object[] {
            "Developer",
            "Software Engineer",
            "System Analyst",
            "DevOps Engineer",
            "Software Tester"});
            this.CMBPos.Location = new System.Drawing.Point(176, 145);
            this.CMBPos.Name = "CMBPos";
            this.CMBPos.Size = new System.Drawing.Size(189, 28);
            this.CMBPos.TabIndex = 4;
            this.CMBPos.SelectedIndexChanged += new System.EventHandler(this.CMBPos_SelectedIndexChanged);
            // 
            // LBLPos
            // 
            this.LBLPos.AutoSize = true;
            this.LBLPos.Location = new System.Drawing.Point(100, 153);
            this.LBLPos.Name = "LBLPos";
            this.LBLPos.Size = new System.Drawing.Size(65, 20);
            this.LBLPos.TabIndex = 0;
            this.LBLPos.Text = "Position";
            // 
            // LBLDays
            // 
            this.LBLDays.AutoSize = true;
            this.LBLDays.Location = new System.Drawing.Point(19, 185);
            this.LBLDays.Name = "LBLDays";
            this.LBLDays.Size = new System.Drawing.Size(146, 20);
            this.LBLDays.TabIndex = 0;
            this.LBLDays.Text = "Total Working Days";
            // 
            // PNLMain
            // 
            this.PNLMain.BackColor = System.Drawing.Color.White;
            this.PNLMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PNLMain.Controls.Add(this.NUMDays);
            this.PNLMain.Controls.Add(this.GRPDeduct);
            this.PNLMain.Controls.Add(this.LBLEmp);
            this.PNLMain.Controls.Add(this.CMBPos);
            this.PNLMain.Controls.Add(this.TXTEmp);
            this.PNLMain.Controls.Add(this.LBLFname);
            this.PNLMain.Controls.Add(this.TXTNet);
            this.PNLMain.Controls.Add(this.TXTDeduct);
            this.PNLMain.Controls.Add(this.TXTSal);
            this.PNLMain.Controls.Add(this.TXTLname);
            this.PNLMain.Controls.Add(this.TXTFname);
            this.PNLMain.Controls.Add(this.LBLDays);
            this.PNLMain.Controls.Add(this.LBLMname);
            this.PNLMain.Controls.Add(this.LBLNet);
            this.PNLMain.Controls.Add(this.LBLPos);
            this.PNLMain.Controls.Add(this.LBLDeduct);
            this.PNLMain.Controls.Add(this.TXTMname);
            this.PNLMain.Controls.Add(this.LBLSal);
            this.PNLMain.Controls.Add(this.LBLLname);
            this.PNLMain.Location = new System.Drawing.Point(8, 7);
            this.PNLMain.Name = "PNLMain";
            this.PNLMain.Size = new System.Drawing.Size(397, 467);
            this.PNLMain.TabIndex = 3;
            // 
            // GRPDeduct
            // 
            this.GRPDeduct.Controls.Add(this.CHKTax);
            this.GRPDeduct.Controls.Add(this.CHKEnsurance);
            this.GRPDeduct.Controls.Add(this.CHKSss);
            this.GRPDeduct.Enabled = false;
            this.GRPDeduct.Location = new System.Drawing.Point(23, 257);
            this.GRPDeduct.Name = "GRPDeduct";
            this.GRPDeduct.Size = new System.Drawing.Size(342, 129);
            this.GRPDeduct.TabIndex = 3;
            this.GRPDeduct.TabStop = false;
            this.GRPDeduct.Text = "Deduction";
            this.GRPDeduct.Enter += new System.EventHandler(this.GRPDeduct_Enter);
            // 
            // CHKSss
            // 
            this.CHKSss.AutoSize = true;
            this.CHKSss.Location = new System.Drawing.Point(30, 29);
            this.CHKSss.Name = "CHKSss";
            this.CHKSss.Size = new System.Drawing.Size(249, 24);
            this.CHKSss.TabIndex = 0;
            this.CHKSss.Text = "SSS, PAGIBIG, PHIL HEALTH";
            this.CHKSss.UseVisualStyleBackColor = true;
            this.CHKSss.CheckedChanged += new System.EventHandler(this.CHKSss_CheckedChanged);
            // 
            // CHKEnsurance
            // 
            this.CHKEnsurance.AutoSize = true;
            this.CHKEnsurance.Location = new System.Drawing.Point(30, 59);
            this.CHKEnsurance.Name = "CHKEnsurance";
            this.CHKEnsurance.Size = new System.Drawing.Size(105, 24);
            this.CHKEnsurance.TabIndex = 0;
            this.CHKEnsurance.Text = "Ensurance";
            this.CHKEnsurance.UseVisualStyleBackColor = true;
            this.CHKEnsurance.CheckedChanged += new System.EventHandler(this.CHKEnsurance_CheckedChanged);
            // 
            // CHKTax
            // 
            this.CHKTax.AutoSize = true;
            this.CHKTax.Location = new System.Drawing.Point(30, 89);
            this.CHKTax.Name = "CHKTax";
            this.CHKTax.Size = new System.Drawing.Size(53, 24);
            this.CHKTax.TabIndex = 0;
            this.CHKTax.Text = "Tax";
            this.CHKTax.UseVisualStyleBackColor = true;
            this.CHKTax.CheckedChanged += new System.EventHandler(this.CHKTax_CheckedChanged);
            // 
            // LBLDeduct
            // 
            this.LBLDeduct.AutoSize = true;
            this.LBLDeduct.Location = new System.Drawing.Point(44, 398);
            this.LBLDeduct.Name = "LBLDeduct";
            this.LBLDeduct.Size = new System.Drawing.Size(121, 20);
            this.LBLDeduct.TabIndex = 0;
            this.LBLDeduct.Text = "Total Deduction";
            // 
            // TXTDeduct
            // 
            this.TXTDeduct.Location = new System.Drawing.Point(176, 392);
            this.TXTDeduct.Name = "TXTDeduct";
            this.TXTDeduct.ReadOnly = true;
            this.TXTDeduct.Size = new System.Drawing.Size(189, 26);
            this.TXTDeduct.TabIndex = 10;
            this.TXTDeduct.Text = "00.00";
            this.TXTDeduct.TextChanged += new System.EventHandler(this.TXTDeduct_TextChanged);
            // 
            // LBLNet
            // 
            this.LBLNet.AutoSize = true;
            this.LBLNet.Location = new System.Drawing.Point(94, 430);
            this.LBLNet.Name = "LBLNet";
            this.LBLNet.Size = new System.Drawing.Size(64, 20);
            this.LBLNet.TabIndex = 0;
            this.LBLNet.Text = "Net Pay";
            // 
            // TXTNet
            // 
            this.TXTNet.Location = new System.Drawing.Point(176, 424);
            this.TXTNet.Name = "TXTNet";
            this.TXTNet.ReadOnly = true;
            this.TXTNet.Size = new System.Drawing.Size(189, 26);
            this.TXTNet.TabIndex = 11;
            this.TXTNet.Text = "00.00";
            // 
            // BTNAdd
            // 
            this.BTNAdd.BackColor = System.Drawing.Color.Black;
            this.BTNAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNAdd.ForeColor = System.Drawing.Color.White;
            this.BTNAdd.Location = new System.Drawing.Point(267, 479);
            this.BTNAdd.Name = "BTNAdd";
            this.BTNAdd.Size = new System.Drawing.Size(138, 28);
            this.BTNAdd.TabIndex = 4;
            this.BTNAdd.Text = "ADD TO LIST";
            this.BTNAdd.UseVisualStyleBackColor = false;
            this.BTNAdd.Click += new System.EventHandler(this.BTNAdd_Click);
            // 
            // LSTMain
            // 
            this.LSTMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LSTMain.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CLMEmp,
            this.CLMFull,
            this.CLMPos,
            this.CLMSal,
            this.CLMDeduct,
            this.CLMNet});
            this.LSTMain.HideSelection = false;
            this.LSTMain.Location = new System.Drawing.Point(411, 7);
            this.LSTMain.Name = "LSTMain";
            this.LSTMain.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LSTMain.Size = new System.Drawing.Size(831, 466);
            this.LSTMain.TabIndex = 5;
            this.LSTMain.UseCompatibleStateImageBehavior = false;
            this.LSTMain.View = System.Windows.Forms.View.Details;
            // 
            // BTNDel
            // 
            this.BTNDel.BackColor = System.Drawing.Color.Maroon;
            this.BTNDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNDel.ForeColor = System.Drawing.SystemColors.Control;
            this.BTNDel.Location = new System.Drawing.Point(1104, 479);
            this.BTNDel.Name = "BTNDel";
            this.BTNDel.Size = new System.Drawing.Size(138, 28);
            this.BTNDel.TabIndex = 12;
            this.BTNDel.Text = "DELETE";
            this.BTNDel.UseVisualStyleBackColor = false;
            this.BTNDel.Click += new System.EventHandler(this.BTNDel_Click);
            // 
            // NUMDays
            // 
            this.NUMDays.Location = new System.Drawing.Point(176, 184);
            this.NUMDays.Name = "NUMDays";
            this.NUMDays.Size = new System.Drawing.Size(189, 26);
            this.NUMDays.TabIndex = 5;
            this.NUMDays.ValueChanged += new System.EventHandler(this.NUMDays_ValueChanged);
            // 
            // LBLSal
            // 
            this.LBLSal.AutoSize = true;
            this.LBLSal.Location = new System.Drawing.Point(73, 223);
            this.LBLSal.Name = "LBLSal";
            this.LBLSal.Size = new System.Drawing.Size(92, 20);
            this.LBLSal.TabIndex = 0;
            this.LBLSal.Text = "Total Salary";
            // 
            // TXTSal
            // 
            this.TXTSal.Location = new System.Drawing.Point(176, 217);
            this.TXTSal.Name = "TXTSal";
            this.TXTSal.ReadOnly = true;
            this.TXTSal.Size = new System.Drawing.Size(189, 26);
            this.TXTSal.TabIndex = 6;
            this.TXTSal.Text = "00.00";
            this.TXTSal.TextChanged += new System.EventHandler(this.TXTSal_TextChanged);
            // 
            // CLMEmp
            // 
            this.CLMEmp.Text = "Emp. No.";
            this.CLMEmp.Width = 95;
            // 
            // CLMFull
            // 
            this.CLMFull.Text = "Full Name";
            this.CLMFull.Width = 200;
            // 
            // CLMPos
            // 
            this.CLMPos.Text = "Position";
            this.CLMPos.Width = 151;
            // 
            // CLMSal
            // 
            this.CLMSal.Text = "Total Salary";
            this.CLMSal.Width = 123;
            // 
            // CLMDeduct
            // 
            this.CLMDeduct.Text = "Total Deduction";
            this.CLMDeduct.Width = 150;
            // 
            // CLMNet
            // 
            this.CLMNet.Text = "Net Pay";
            this.CLMNet.Width = 282;
            // 
            // FRMMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1248, 510);
            this.Controls.Add(this.LSTMain);
            this.Controls.Add(this.BTNDel);
            this.Controls.Add(this.BTNAdd);
            this.Controls.Add(this.PNLMain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FRMMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Salary Calculator";
            this.PNLMain.ResumeLayout(false);
            this.PNLMain.PerformLayout();
            this.GRPDeduct.ResumeLayout(false);
            this.GRPDeduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUMDays)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LBLEmp;
        private System.Windows.Forms.TextBox TXTEmp;
        private System.Windows.Forms.Label LBLFname;
        private System.Windows.Forms.TextBox TXTFname;
        private System.Windows.Forms.Label LBLMname;
        private System.Windows.Forms.TextBox TXTMname;
        private System.Windows.Forms.Label LBLLname;
        private System.Windows.Forms.TextBox TXTLname;
        private System.Windows.Forms.ComboBox CMBPos;
        private System.Windows.Forms.Label LBLPos;
        private System.Windows.Forms.Label LBLDays;
        private System.Windows.Forms.Panel PNLMain;
        private System.Windows.Forms.GroupBox GRPDeduct;
        private System.Windows.Forms.CheckBox CHKTax;
        private System.Windows.Forms.CheckBox CHKEnsurance;
        private System.Windows.Forms.CheckBox CHKSss;
        private System.Windows.Forms.TextBox TXTNet;
        private System.Windows.Forms.TextBox TXTDeduct;
        private System.Windows.Forms.Label LBLNet;
        private System.Windows.Forms.Label LBLDeduct;
        private System.Windows.Forms.Button BTNAdd;
        private System.Windows.Forms.ListView LSTMain;
        private System.Windows.Forms.Button BTNDel;
        private System.Windows.Forms.NumericUpDown NUMDays;
        private System.Windows.Forms.TextBox TXTSal;
        private System.Windows.Forms.Label LBLSal;
        private System.Windows.Forms.ColumnHeader CLMEmp;
        private System.Windows.Forms.ColumnHeader CLMFull;
        private System.Windows.Forms.ColumnHeader CLMPos;
        private System.Windows.Forms.ColumnHeader CLMSal;
        private System.Windows.Forms.ColumnHeader CLMDeduct;
        private System.Windows.Forms.ColumnHeader CLMNet;
    }
}

