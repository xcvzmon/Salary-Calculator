﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salary_Calculator
{
    public partial class FRMMain : Form
    {
        public FRMMain()
        {
            InitializeComponent();
            NUMDays.Text = "0";
        }

        double pos, ens = 0, sss = 0, tax = 0;

        private void TXTSal_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToDouble(TXTSal.Text) >= 10000)
            {
                GRPDeduct.Enabled = true;
            }
            else
            {
                GRPDeduct.Enabled = false;
                CHKEnsurance.Checked = false;
                CHKSss.Checked = false;
                CHKTax.Checked = false;
            }
        }

        private void CMBPos_SelectedIndexChanged(object sender, EventArgs e)
        {
            

            if (CMBPos.Text == "Developer")
            {
                pos = 1500.00;
            }
            else if (CMBPos.Text == "Software Engineer")
            {
                pos = 2000.00;
            }
            else if (CMBPos.Text == "System Analyst")
            {
                pos = 1000.00;
            }
            else if (CMBPos.Text == "DevOps Engineer")
            {
                pos = 2500.00;
            }
            else if (CMBPos.Text == "Software Tester")
            {
                pos = 1000.00;
            }
            else
            {
                pos = 00.00;
            }

            Decimal s = NUMDays.Value;

            TXTSal.Text = Convert.ToString(Convert.ToDouble(s) * pos);
            TXTNet.Text = Convert.ToString(Convert.ToDouble(TXTSal.Text) - Convert.ToDouble(TXTDeduct.Text));
        }

        private void CHKEnsurance_CheckedChanged(object sender, EventArgs e)
        {
            if (CHKEnsurance.Checked == true)
            {
                ens = 500;
            }
            else
            {
                ens = 0;
            }

            TXTDeduct.Text = Convert.ToString(sss + ens + tax);
            TXTNet.Text = Convert.ToString(Convert.ToDouble(TXTSal.Text) - Convert.ToDouble(TXTDeduct.Text));
        }

        private void GRPDeduct_Enter(object sender, EventArgs e)
        {

        }

        private void CHKTax_CheckedChanged(object sender, EventArgs e)
        {
            if (CHKTax.Checked == true)
            {
                tax = 0.05 * Convert.ToDouble(TXTSal.Text);
            }
            else
            {
                tax = 0;
            }

            TXTDeduct.Text = Convert.ToString(sss + ens + tax);
            TXTNet.Text = Convert.ToString(Convert.ToDouble(TXTSal.Text) - Convert.ToDouble(TXTDeduct.Text));
        }

        private void BTNAdd_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(TXTEmp.Text) || String.IsNullOrEmpty(TXTFname.Text) || String.IsNullOrEmpty(TXTMname.Text) || String.IsNullOrEmpty(TXTLname.Text) || String.IsNullOrEmpty(CMBPos.Text))
            {
                MessageBox.Show("Incomplete Information! Please fill out all the boxes", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                ListViewItem item = new ListViewItem(TXTEmp.Text);
                item.SubItems.Add(TXTFname.Text + TXTMname.Text + TXTLname.Text);
                item.SubItems.Add(CMBPos.Text);
                item.SubItems.Add(TXTSal.Text);
                item.SubItems.Add(TXTDeduct.Text);
                item.SubItems.Add(TXTNet.Text);
                LSTMain.Items.Add(item);

                TXTEmp.Clear();
                TXTFname.Clear();
                TXTMname.Clear();
                TXTLname.Clear();
                CMBPos.Text = "";
                NUMDays.Text = "0";
                TXTSal.Text = "00.00";
                TXTDeduct.Text = "00.00";
                TXTNet.Text = "00.00";
                TXTEmp.Focus();
            }
        }

        private void BTNDel_Click(object sender, EventArgs e)
        {
            if (LSTMain.Items.Count > 0)
            {
                    LSTMain.Items.Remove(LSTMain.SelectedItems[0]);
            }
        }

        private void NUMDays_ValueChanged(object sender, EventArgs e)
        {
            Decimal s = NUMDays.Value;

            TXTSal.Text = Convert.ToString(Convert.ToDouble(s) * pos);
            TXTNet.Text = Convert.ToString(Convert.ToDouble(TXTSal.Text) - Convert.ToDouble(TXTDeduct.Text));
        }

        private void CHKSss_CheckedChanged(object sender, EventArgs e)
        {
            if (CHKSss.Checked == true)
            {
                sss = 600;
            }
            else
            {
                sss = 0;
            }

            TXTDeduct.Text = Convert.ToString(sss + ens + tax);
            TXTNet.Text = Convert.ToString(Convert.ToDouble(TXTSal.Text) - Convert.ToDouble(TXTDeduct.Text));
        }

        private void TXTDeduct_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
